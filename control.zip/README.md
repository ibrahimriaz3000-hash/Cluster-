# iOS Connect Cluster (LSPosed)
SystemUI me Control Center ki "No playback" media card ki jaga 2x2 cluster: Data, Wi-Fi, Hotspot, Bluetooth.

## Build (GitHub se)
1. Is folder ko naye GitHub repo me push karo (.github/workflows/build.yml saath jaye).
2. Actions tab -> "Build APK" -> artifact `IOSConnectCluster-apk` download.
3. APK install -> LSPosed me enable, scope: System UI -> SystemUI restart (ya reboot).
Agar `de.robv.android.xposed:api:82` download fail ho to XposedBridgeAPI-82.jar `app/libs/` me daal do.

## Debug
LSPosed logs me "IOSConnect:" dhundo. "MediaPlayerPanel mil gaya" aaye to hook lag gaya.
