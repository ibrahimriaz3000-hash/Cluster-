package com.cc.iosconnect;

import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.ContentObserver;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.view.MotionEvent;
import android.view.View;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.concurrent.Executor;

import de.robv.android.xposed.XposedBridge;

/** Ek gol tile: apna icon khud draw karta hai (module resources ki zaroorat nahi). */
public class TileView extends View {
    public static final int DATA = 0, WIFI = 1, HOTSPOT = 2, BT = 3;

    // ---- Rang yahan badlo ----
    static final int ON_BG = 0xFF0A84FF;     // active gol (iOS neela)
    static final int ON_ICON = 0xFFFFFFFF;
    static final int OFF_BG = 0x66FFFFFF;    // inactive gol
    static final int OFF_ICON = 0xFFFFFFFF;

    private final int kind;
    private boolean active;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Handler main = new Handler(Looper.getMainLooper());

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { refresh(); }
    };
    private final ContentObserver observer = new ContentObserver(main) {
        @Override public void onChange(boolean selfChange) { refresh(); }
    };

    public TileView(Context c, int kind) {
        super(c);
        this.kind = kind;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        fill.setStyle(Paint.Style.FILL);
        setClickable(true);
        setOnClickListener(v -> toggle());
        setOnLongClickListener(v -> { openSettings(); return true; });
    }

    // ------------------------------------------------------------ state
    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        IntentFilter f = new IntentFilter();
        f.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        f.addAction("android.net.wifi.WIFI_AP_STATE_CHANGED");
        f.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        try { getContext().registerReceiver(receiver, f); } catch (Throwable ignored) { }
        try {
            getContext().getContentResolver().registerContentObserver(
                    Settings.Global.getUriFor("mobile_data"), false, observer);
        } catch (Throwable ignored) { }
        refresh();
    }

    @Override protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        try { getContext().unregisterReceiver(receiver); } catch (Throwable ignored) { }
        try { getContext().getContentResolver().unregisterContentObserver(observer); } catch (Throwable ignored) { }
    }

    private void refresh() {
        boolean s = false;
        try {
            Context c = getContext();
            switch (kind) {
                case WIFI:
                    s = ((WifiManager) c.getSystemService(Context.WIFI_SERVICE)).isWifiEnabled();
                    break;
                case BT:
                    BluetoothAdapter a = BluetoothAdapter.getDefaultAdapter();
                    s = a != null && a.isEnabled();
                    break;
                case DATA:
                    s = c.getSystemService(TelephonyManager.class).isDataEnabled();
                    break;
                case HOTSPOT:
                    s = isHotspotOn();
                    break;
            }
        } catch (Throwable t) {
            XposedBridge.log("IOSConnect: refresh " + kind + ": " + t);
        }
        if (s != active) { active = s; invalidate(); }
    }

    private boolean isHotspotOn() {
        try {
            WifiManager wm = (WifiManager) getContext().getSystemService(Context.WIFI_SERVICE);
            Method m = WifiManager.class.getMethod("isWifiApEnabled");
            return (Boolean) m.invoke(wm);
        } catch (Throwable t) { return false; }
    }

    // ------------------------------------------------------------ actions
    @SuppressWarnings("deprecation")
    private void toggle() {
        Context c = getContext();
        boolean target = !active;
        try {
            switch (kind) {
                case WIFI:
                    ((WifiManager) c.getSystemService(Context.WIFI_SERVICE)).setWifiEnabled(target);
                    break;
                case BT:
                    BluetoothAdapter a = BluetoothAdapter.getDefaultAdapter();
                    if (a != null) { if (target) a.enable(); else a.disable(); }
                    break;
                case DATA:
                    c.getSystemService(TelephonyManager.class).setDataEnabled(target);
                    break;
                case HOTSPOT:
                    setHotspot(target);
                    break;
            }
            active = target;       // foran feedback; asal state receiver se sync hogi
            invalidate();
            main.postDelayed(this::refresh, 1500);
        } catch (Throwable t) {
            XposedBridge.log("IOSConnect: toggle " + kind + " fail: " + t);
            openSettings();
        }
    }

    private void setHotspot(boolean on) throws Exception {
        Context c = getContext();
        Object tm = c.getSystemService("tethering");           // android.net.TetheringManager
        if (on) {
            Class<?> cbType = Class.forName("android.net.TetheringManager$StartTetheringCallback",
                    false, tm.getClass().getClassLoader());
            Object cb = Proxy.newProxyInstance(cbType.getClassLoader(), new Class<?>[]{cbType},
                    new InvocationHandler() {
                        @Override public Object invoke(Object p, Method m, Object[] a) {
                            switch (m.getName()) {
                                case "hashCode": return System.identityHashCode(p);
                                case "equals": return p == a[0];
                                case "toString": return "HotspotCb";
                                default: return null;
                            }
                        }
                    });
            Method m = tm.getClass().getMethod("startTethering", int.class, Executor.class, cbType);
            m.invoke(tm, 0 /* TETHERING_WIFI */, c.getMainExecutor(), cb);
        } else {
            tm.getClass().getMethod("stopTethering", int.class).invoke(tm, 0);
        }
    }

    private void openSettings() {
        try {
            Intent i;
            switch (kind) {
                case WIFI: i = new Intent(Settings.ACTION_WIFI_SETTINGS); break;
                case BT: i = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS); break;
                case DATA: i = new Intent(Settings.ACTION_DATA_ROAMING_SETTINGS); break;
                default:
                    i = new Intent().setClassName("com.android.settings",
                            "com.android.settings.Settings$TetherSettingsActivity");
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
        } catch (Throwable t) {
            XposedBridge.log("IOSConnect: openSettings fail: " + t);
        }
    }

    // ------------------------------------------------------------ touch feedback
    @Override public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: animate().scaleX(0.92f).scaleY(0.92f).setDuration(90).start(); break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: animate().scaleX(1f).scaleY(1f).setDuration(120).start(); break;
        }
        return super.onTouchEvent(e);
    }

    // ------------------------------------------------------------ drawing
    @Override protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight();
        float cx = w / 2f, cy = h / 2f, r = Math.min(w, h) / 2f;
        fill.setColor(active ? ON_BG : OFF_BG);
        cv.drawCircle(cx, cy, r, fill);

        int ic = active ? ON_ICON : OFF_ICON;
        float s = r * 0.46f;                       // icon ka unit size
        stroke.setColor(ic);
        stroke.setStrokeWidth(s * 0.2f);
        fill.setColor(ic);
        switch (kind) {
            case WIFI: drawWifi(cv, cx, cy, s); break;
            case BT: drawBt(cv, cx, cy, s); break;
            case DATA: drawData(cv, cx, cy, s); break;
            case HOTSPOT: drawHotspot(cv, cx, cy, s); break;
        }
    }

    private void arc(Canvas cv, float cx, float cy, float rad, float start, float sweep) {
        rect.set(cx - rad, cy - rad, cx + rad, cy + rad);
        cv.drawArc(rect, start, sweep, false, stroke);
    }

    private void drawWifi(Canvas cv, float cx, float cy, float s) {
        float by = cy + 0.55f * s;
        cv.drawCircle(cx, by, 0.17f * s, fill);
        arc(cv, cx, by, 0.65f * s, 225, 90);
        arc(cv, cx, by, 1.15f * s, 225, 90);
        arc(cv, cx, by, 1.65f * s, 225, 90);
    }

    private void drawHotspot(Canvas cv, float cx, float cy, float s) {
        cv.drawCircle(cx, cy, 0.22f * s, fill);
        arc(cv, cx, cy, 0.75f * s, 135, 90);
        arc(cv, cx, cy, 0.75f * s, -45, 90);
        arc(cv, cx, cy, 1.3f * s, 135, 90);
        arc(cv, cx, cy, 1.3f * s, -45, 90);
    }

    private void drawBt(Canvas cv, float cx, float cy, float s) {
        float[][] p = {{-0.55f, -0.45f}, {0.55f, 0.45f}, {0f, 1f}, {0f, -1f}, {0.55f, -0.45f}, {-0.55f, 0.45f}};
        for (int i = 0; i < p.length - 1; i++) {
            cv.drawLine(cx + p[i][0] * s, cy + p[i][1] * s, cx + p[i + 1][0] * s, cy + p[i + 1][1] * s, stroke);
        }
    }

    private void drawData(Canvas cv, float cx, float cy, float s) {
        float lx = cx - 0.5f * s, rx = cx + 0.5f * s;
        // left: neeche wala teer
        cv.drawLine(lx, cy - 0.9f * s, lx, cy + 0.9f * s, stroke);
        cv.drawLine(lx, cy + 0.9f * s, lx - 0.4f * s, cy + 0.5f * s, stroke);
        cv.drawLine(lx, cy + 0.9f * s, lx + 0.4f * s, cy + 0.5f * s, stroke);
        // right: upar wala teer
        cv.drawLine(rx, cy + 0.9f * s, rx, cy - 0.9f * s, stroke);
        cv.drawLine(rx, cy - 0.9f * s, rx - 0.4f * s, cy - 0.5f * s, stroke);
        cv.drawLine(rx, cy - 0.9f * s, rx + 0.4f * s, cy - 0.5f * s, stroke);
    }
}
